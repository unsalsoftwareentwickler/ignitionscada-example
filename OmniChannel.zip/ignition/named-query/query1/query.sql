SELECT processrevision.id,
  processrevision.process_adi,
  processrevision.processpdfasdresi,
  processrevision.datetime
FROM processrevision